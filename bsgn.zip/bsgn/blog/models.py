from django.contrib.auth.models import User


from django.db import models
class Role(models.Model):
    users=models.ManyToManyField(User, blank=True, default='')
    rolename=models.CharField(max_length=150, null=True, blank=True, default='')
    is_role = models.BooleanField(default=False)
    def __str__(self):
        return f"{self.rolename}"

class Post(models.Model):
    title = models.CharField(max_length=250)
    desc=models.TextField()