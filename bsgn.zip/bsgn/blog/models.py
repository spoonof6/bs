from django.contrib.auth.models import User


from django.db import models
class Role(models.Model):
    users=models.ManyToManyField(User, blank=True, default='')
    rolename=models.CharField(max_length=150, null=True, blank=True, default='')

    home_html = models.BooleanField(default=False)
    contact_html = models.BooleanField(default=False)
    admin_html = models.BooleanField(default=False)
    dashboard_html = models.BooleanField(default=False)
    user_role_html = models.BooleanField(default=False)
    change_password_html = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.rolename}"


    # access_aboutus = models.BooleanField(default=False)

class Post(models.Model):
    title = models.CharField(max_length=250)
    desc=models.TextField()