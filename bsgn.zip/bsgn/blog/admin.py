from django.contrib import admin

from blog.models import Role
admin.site.register(Role)
