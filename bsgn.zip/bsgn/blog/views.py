from django.shortcuts import redirect, render,HttpResponseRedirect
from django.views.decorators.cache import cache_control
from .forms import SignUpForm,LoginForm,PostForm
from django.contrib import messages,auth
from django.contrib.auth import authenticate,login,logout
from .models import Post
from django.contrib.auth.models import Group
from django.contrib.auth.forms import PasswordChangeForm
from django.contrib.auth import update_session_auth_hash
from django.contrib.auth.decorators import login_required
from django.contrib.auth import get_user_model
from blog.models import Role




# Create your views here.
User = get_user_model()
# HOME-PAGE
@login_required(login_url='login')
def home(request):
    posts = Post.objects.all()
    data =  Role.objects.filter(users=request.user)
    context = {'data': data, 'posts':posts}
    return render(request,'blog/home.html',context)


# CONTACT-PAGE
def contact(request):
    return render(request,'blog/contact.html')


# DASHBOARD-PAGE
@login_required(login_url='login')
@cache_control(no_cache=True, must_revalidate=True, no_store=True)
def dashboard(request):
    if request.user.is_authenticated:
        User = get_user_model()
        posts = Post.objects.all()
        user = request.user
        print(user)
        # full_name = user.get_full_name()
        gps = user.groups.all()
        return render(request,'blog/dashboard.html',{'posts':posts,'groups':gps})
    else:
        return HttpResponseRedirect('/login/')


# USER-LOGOUT
def user_logout(request):
    logout(request)
    return HttpResponseRedirect('/')


# USER SIGN-UP-PAGE
def user_signup(request):
    if request.method == "POST":
        form = SignUpForm(request.POST)
        if form.is_valid():
            email = request.POST.get('email')
            User = get_user_model()
            if User.objects.filter(email=email).exists():
                messages.warning(request,'This EmailId Is Already Registered With Us.')
                return redirect('signup')
            else:
                User = get_user_model()
                messages.success(request,'Congratulations!! You Have Become An Author.')
                user = form.save()
                group = Group.objects.get(name='Author')
                user.groups.add(group)
                return HttpResponseRedirect('/login/')
    else:
        form = SignUpForm()
    return render(request, 'blog/signup.html',{'form':form})


# USER LOGIN-PAGE
@cache_control(no_cache=True, must_revalidate=True, no_store=True)
def user_login(request):
        if request.method == "POST":
            form = LoginForm(request.POST,data=request.POST)
            if form.is_valid():
                uname = form.cleaned_data['username']
                upass = form.cleaned_data['password']
                user = authenticate(username=uname,password=upass)
                if user is not None:
                    login(request,user)
                    messages.success(request,'Logged In Successfully !!')
                    return HttpResponseRedirect('/')
        else:
            form = LoginForm()
        return render(request,'blog/login.html',{'form':form})
    
    
# ADD POST 
def add_post(request):
    if request.user.is_authenticated:
        if request.method == "POST":
            form = PostForm(request.POST)
            if form.is_valid():
                title = form.cleaned_data['title']
                desc = form.cleaned_data['desc']
                pst = Post(title=title,desc=desc)
                messages.success(request,'Congratulations !! Your Post Is Successfully Added. ')
                pst.save()
                return HttpResponseRedirect('/dashboard/')
        else:
            form = PostForm()
        return render(request,'blog/addpost.html',{'form':form})
    else:
        HttpResponseRedirect('/login/')


# UPDATE POST
def update_post(request, id):
    if request.user.is_authenticated:
        if request.method == "POST":
            pi = Post.objects.get(pk=id)
            form = PostForm(request.POST, instance=pi)
            messages.success(request,'Congratulations !! Your Post Is Successfully Updated. ')
            if form.is_valid():
                form.save()
        else:
            pi = Post.objects.get(pk=id)
            form = PostForm(instance=pi)
        
        return render(request,'blog/updatepost.html',{'form':form})
    else:
        HttpResponseRedirect('/login/')


# DELETE POST
def delete_post(request, id):
    if request.user.is_authenticated:
        if request.user.is_authenticated:
            if request.method =="POST":
                pi = Post.objects.get(pk=id)
                messages.success(request,'Your Post Is Successfully Deleted. ')
                pi.delete()
                return HttpResponseRedirect('/dashboard/')
    else:
        HttpResponseRedirect('/login/')


# CHANGE-PASSWORD PAGE
@login_required(login_url='login')
def change_password(request):
    if request.method == 'POST':
        form = PasswordChangeForm(request.user, request.POST)
        if form.is_valid():
            user = form.save()
            update_session_auth_hash(request, user)
            messages.success(request, 'Your password was successfully updated!')
            return redirect('change_password')
        else:
            messages.warning(request, 'Your password does not match !!')
            return render(request, 'blog/change_password.html', {'form': form})
    else:
        form = PasswordChangeForm(request.user)
        return render(request, 'blog/change_password.html', {'form': form})
    








